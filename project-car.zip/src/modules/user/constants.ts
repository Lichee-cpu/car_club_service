export const jwtConstants = {
  secret: 'secretKey',  //常量定义
};
